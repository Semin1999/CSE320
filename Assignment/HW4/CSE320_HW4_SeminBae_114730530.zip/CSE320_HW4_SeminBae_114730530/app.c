//app.c
//
#include <stdio.h>


int main() {
    printf("--- Run App HW4 ---\n--- Name: Semin Bae(114730530) ---\n--- Email: semin.bae@stonybrook.edu ---\n");

    extern void unit_test();
    unit_test();
}