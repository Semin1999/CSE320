#include <stdio.h>
int main(){
printf("This is the sample c programming for the assignment 1");
}
